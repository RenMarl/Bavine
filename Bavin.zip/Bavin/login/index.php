<?php

require_once('login.function.php');

require_once('view.login.php');