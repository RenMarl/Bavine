<?php

class Product {
  
  public $model;
  public $color;
  public $brand;
  public $price;
  public $image;
  public $mah;
  public $starCount;
  

// __Constructor
  public function __construct($model, $color, $brand, $price) {
    $this->model = $model;
    $this->color = $color;
    $this->brand = $brand;
    $this->price = $price;
  }

}
  // Inheritance    (Charger() is inherited from Product())
class Charger extends Product  {
  // getter
  public function getImage() {
    return $this->image;
  }
}

class Powerbank extends Product  {
  public function getImage() {
    return $this->image;
  }
  public function mAh() {
    return $this->mah;
  }
}

class EarBuds extends Product  {
  public $wired;
  public function __construct($model, $color, $brand, $price, $wired, $image) {

    parent::__construct($model, $color, $brand, $price); // call the constructor of the parent class
    
    $this->wired = $wired;
    $this->image = $image;      // without getImage() method

}
  // public function isWireless() {
  //   return !$this->wired;
  // }

  // public function isWired() {
  //   return $this->wired;
  // }

}