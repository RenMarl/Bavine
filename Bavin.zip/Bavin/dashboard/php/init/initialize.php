<?php

require('product.php');
//                Model       Color            Brand             Price             *Image*
// Objects are created using 'new' keyword
// $charger1 is instance of the class Charger()
// instantiate
$charger1 = new Charger('PC516', 'White', 'BAVIN', 165.00);
// like setter
// separate 'image' in __construct with long link/name/directoryPath/location
$charger1->image ='img/BAVIN PC516 Mini Universal Quick Charger Adapter With 1 Meter Data Cable For Micro iPh Type-C.jpg';

$charger2 = new Charger('PC315', 'White', 'BAVIN', 309.00);
$charger2->image ='img/BAVIN PC315 Qualcomm3.0 Fast Charging Charger.jpg';

$charger3 = new Charger('PC586', 'White', 'BAVIN', 309.00);
$charger3->image ='img/BAVIN PC586 QC3.0 Fast Charger Max Qualcomm USB Wall Charger for Micro Type-C  For iPhone.jpg';

$pb1 = new Powerbank('PC091', 'Black', 'BAVIN', 449.00);
$pb1->image ='img/BAVIN PC091.jpg';
$pb1->mah ='10000/20000mAh';
$pb1->starCount = 3;

$pb2 = new Powerbank('PC1025S', 'Black/RGB', 'BAVIN', '2,999.00');
$pb2->image ='img/BAVIN PC1022 PC1025S 30000mAh 100W 22 5W.jpg';
$pb2->mah ='30000mAh';

$pb3 = new Powerbank('PC1012', 'Grey', 'BAVIN', 699.00);
$pb3->image ='img/BAVIN PC1012 10000mAh 22.5W Fast Charging Powerbank w Type-C Input Output & 22.5 Watts Fast Charge.jpg';
$pb3->mah ='10000mAh';

// without getImage() method, Directing image within Constructor
$eb1 = new EarBuds('BA09', 'Green', 'BAVIN',969.00,'Wireless', 'img/BAVIN BA09 Hi-Fi TWS Bluetooth 5.2 Wireless Dynamic Earphone HiFi Stereo Sound Metal Shell Earbuds.jpg' );
$eb1->starCount = 3;

$eb2 = new EarBuds('BA20', 'Yellow', 'BAVIN','1,499.00','Wireless', 'img/BAVIN BA20 TWS Bluetooth 5.1 Wireless Earphone Gaming Focus Active Noise Reduction Touch Control.jpg');
$eb2->starCount = 3;



// if ($eb1 && $eb2 ->isWireless()) {
//     return "Wireless";
//   } else {
//     return "Wired";
//   }


// echo "<pre>";
// print_r($asusRog513);

// print_r($acerPred);
// die();
// echo $asusRog513->model;